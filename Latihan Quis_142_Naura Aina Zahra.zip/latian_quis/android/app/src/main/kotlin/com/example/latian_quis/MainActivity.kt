package com.example.latian_quis

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
